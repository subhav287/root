$(function() {
	$('#driverID').focus();

	$('#driverIDForm').on(
			'submit',
			function() {
				var $form = $(this);
				return isNotEmpty($form.find('#driverID'),
						"Please enter only number!", $form
								.find('#driverIDError'));
			});

	$('#btnReset').on('click', function() {
		$('.errorBox').removeClass('errorBox');
		$('td[id$="Error"]').html('');
		$('driverIDError').focus();
	});
});

function postValidate(isValid, errMsg, errElm, inputElm) {
	if (!isValid) {
		if (errElm !== undefined && errElm !== null && errMsg !== undefined
				&& errMsg !== null) {
			errElm.html(errMsg);
		}
		if (inputElm !== undefined && inputElm !== null) {
			inputElm.addClass("errorBox");
			inputElm.focus();
		}
	} else {
		if (errElm !== undefined && errElm !== null) {
			errElm.html('');
		}
		if (inputElm !== undefined && inputElm !== null) {
			inputElm.removeClass("errorBox");
		}
	}
}

function isNotEmpty(inputElm, errMsg, errElm) {
	var inputValue = inputElm.val()
	var isValid = $.isNumeric(inputValue);
	postValidate(isValid, errMsg, errElm, inputElm);
	return isValid;
}