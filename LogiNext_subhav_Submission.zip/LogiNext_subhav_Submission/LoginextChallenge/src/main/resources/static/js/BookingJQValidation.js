$(function() {
	$('#custName').focus();

	$('#bookingForm').on(
			'submit',
			function() {
				var $form = $(this);
				return isNotEmpty($form.find('#custName'),
						"Please enter your name!(Max 30 characters)", $form
								.find('#custNameError'))
						&& isValidLatitude($form.find('#custLatitude'),
								"Please enter a Valid Latitude!", $form
										.find('#elmLatitudeError'))
						&& isValidLongitude($form.find('#custLongitude'),
								"Please enter a Longitude!", $form
										.find('#elmLongitudeError'));
			});

	$('#btnReset').on('click', function() {
		$('.errorBox').removeClass('errorBox');
		$('td[id$="Error"]').html('');
		$('custName').focus();
	});
});

function postValidate(isValid, errMsg, errElm, inputElm) {
	if (!isValid) {
		if (errElm !== undefined && errElm !== null && errMsg !== undefined
				&& errMsg !== null) {
			errElm.html(errMsg);
		}
		if (inputElm !== undefined && inputElm !== null) {
			inputElm.addClass("errorBox");
			inputElm.focus();
		}
	} else {
		if (errElm !== undefined && errElm !== null) {
			errElm.html('');
		}
		if (inputElm !== undefined && inputElm !== null) {
			inputElm.removeClass("errorBox");
		}
	}
}

function isNotEmpty(inputElm, errMsg, errElm) {
	var inputValue = inputElm.val()
	var isValid = (inputValue.length <= 30 && inputValue.trim() !== "");
	postValidate(isValid, errMsg, errElm, inputElm);
	return isValid;
}

function isValidLatitude(inputElm, errMsg, errElm) {
	var inputValue = inputElm.val().trim();
	var isValid = !((inputValue.match(/[^0-9.\-+]+$/) !== null) && (-90 > inputValue < 90));
	postValidate(isValid, errMsg, errElm, inputElm);
	return isValid;
}

function isValidLongitude(inputElm, errMsg, errElm) {
	var inputValue = inputElm.val().trim();
	var isValid = !((inputValue.match(/[^0-9.\-+]+$/) !== null) && (-180 > inputValue < 180));
	postValidate(isValid, errMsg, errElm, inputElm);
	return isValid;
}