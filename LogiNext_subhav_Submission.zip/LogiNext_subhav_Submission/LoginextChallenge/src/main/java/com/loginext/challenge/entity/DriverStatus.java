package com.loginext.challenge.entity;

public class DriverStatus {
	private int driverID;
	private double driverLatitude;
	private double driverLongitude;
	private DriversStatusus status;
	
	public int getDriverID() {
		return driverID;
	}
	
	public void setDriverID(int driverID) {
		this.driverID = driverID;
	}
	public double getDriverLatitude() {
		return driverLatitude;
	}
	public void setDriverLatitude(double driverLatitude) {
		this.driverLatitude = driverLatitude;
	}
	public double getDriverLongitude() {
		return driverLongitude;
	}
	public void setDriverLongitude(double driverLongitude) {
		this.driverLongitude = driverLongitude;
	}
	public DriversStatusus getStatus() {
		return status;
	}
	
	public void setStatus(DriversStatusus status) {
		this.status = status;
	}
}
