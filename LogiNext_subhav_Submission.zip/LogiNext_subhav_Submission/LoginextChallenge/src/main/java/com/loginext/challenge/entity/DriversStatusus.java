package com.loginext.challenge.entity;

public enum DriversStatusus {
	BUSY("BUSY"), AVAILABLE("AVAILABLE");
	
	private String text;
	
	DriversStatusus(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}
}
