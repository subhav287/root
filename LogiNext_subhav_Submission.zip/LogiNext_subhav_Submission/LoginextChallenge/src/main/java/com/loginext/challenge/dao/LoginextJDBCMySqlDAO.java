package com.loginext.challenge.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.loginext.challenge.entity.Booking;
import com.loginext.challenge.entity.Driver;
import com.loginext.challenge.entity.DriverStatus;
import com.loginext.challenge.entity.DriversStatusus;
import com.loginext.challenge.model.BookingDisplay;
import com.loginext.challenge.model.DriverStatusDisplay;

@Repository
public class LoginextJDBCMySqlDAO implements ILoginextDAO {
	private static final String GET_ALL_AVAILABLE_DRIVERS = "select driver_id, driver_latitude, driver_longitude, status from loginext.driver_status where status = 'AVAILABLE'";
	private static final String GET_ALL_DRIVER_DETAILS_WITH_STATUS_FOR_DISPLAY = "select d.driver_id, d.driver_name, d.phone_no, d.vehicle_id, ds.driver_latitude, ds.driver_longitude, ds.status from loginext.driver d left outer join loginext.driver_status ds on d.driver_id = ds.driver_id";
	private static final String GET_DRIVER_AND_STATUS_DETAILS_BY_DRIVER_ID = "select d.driver_id, d.driver_name, d.phone_no, ds.driver_latitude, ds.driver_longitude, ds.status from loginext.driver d left outer join loginext.driver_status ds on d.driver_id = ds.driver_id where d.driver_id = :driverID limit 1";
	private static final String CREATE_BOOKING = "insert into loginext.booking(driver_id, customer_name, customer_latitude, customer_longitude, is_active) values (:driverID, :customerName, :customerLatitude, :customerLongitude, 1);";
	private static final String UPDATE_DRIVER_STATUS = "update loginext.driver_status set status = :status where driver_id = :driverID";
	private static final String UPDATE_DRIVER_STATUS_AND_COORDINATES = "update loginext.driver_status set status = :status, driver_latitude = :latitude, driver_longitude = :longitude where driver_id = :driverID";
	private static final String UPDATE_DRIVER_COORDINATES = "update loginext.driver_status set driver_latitude = :driverLatitude, driver_longitude = :driverLongitude where driver_id = :driverID";
	private static final String MARK_OLD_BOOKINGS_INACTIVE = "update loginext.booking set is_active = 0 where driver_id = :driverID";
	private static final String GET_COMPLETE_BOOKING_INFO = "select booking_id, customer_name, customer_latitude, customer_longitude, driver_name, d.phone_no  as 'driver_phone_no', driver_latitude, driver_longitude, v.vehicle_type, v.vehicle_capacity, v.manufacturer, v.model from loginext.booking b inner join loginext.driver d on d.driver_id = b.driver_id inner join loginext.driver_status ds on ds.driver_id = d.driver_id inner join loginext.vehicle v on v.vehicle_id = d.vehicle_id where d.driver_id = :driverID and is_active = 1";

	@Autowired
	private NamedParameterJdbcTemplate template;

	@Override
	public void updateDriversCoordinates(List<DriverStatus> driverStatusList) {
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(driverStatusList.toArray());
		template.batchUpdate(UPDATE_DRIVER_COORDINATES, batch);
	}

	@Override
	public int updateDriverStatus(int driverID, String status) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("driverID", driverID);
		params.addValue("status", status);
		return template.update(UPDATE_DRIVER_STATUS, params);
	}
	
	@Override
	public int updateDriverStatusAndCoordinates(int driverID, String status, double latitude, double longitude) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("driverID", driverID);
		params.addValue("status", status);
		params.addValue("latitude", latitude);
		params.addValue("longitude", longitude);
		return template.update(UPDATE_DRIVER_STATUS_AND_COORDINATES, params);
	}

	@Override
	public void createBooking(Booking booking) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("customerName", booking.getCustomerName());
		params.addValue("driverID", booking.getDriverID());
		params.addValue("customerLatitude", booking.getCustomerLatitude());
		params.addValue("customerLongitude", booking.getCustomerLongitude());
		template.update(CREATE_BOOKING, params);
	}
	
	@Override
	public DriverStatusDisplay getDriverAndStatusDetailsByDriverID(int driverID) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("driverID", driverID);
		return template.queryForObject(GET_DRIVER_AND_STATUS_DETAILS_BY_DRIVER_ID, params, (rs, rowNum) -> {
			Driver d = new Driver();
			DriverStatus ds = new DriverStatus();
			DriverStatusDisplay dsd = new DriverStatusDisplay(d, ds);
			d.setDriverID(rs.getInt("DRIVER_ID"));
			d.setDriverName(rs.getString("DRIVER_NAME"));
			d.setPhoneNo(rs.getString("PHONE_NO"));
			ds.setDriverID(rs.getInt("DRIVER_ID"));
			ds.setDriverLatitude(rs.getDouble("DRIVER_LATITUDE"));
			ds.setDriverLongitude(rs.getDouble("DRIVER_LONGITUDE"));
			ds.setStatus(DriversStatusus.valueOf(rs.getString("STATUS")));
			return dsd;
		});
	}
	
	@Override
	public List<DriverStatus> getAllAvailableDrivers() {
		return template.query(GET_ALL_AVAILABLE_DRIVERS, (rs, rowNum) -> {
			DriverStatus ds = new DriverStatus();
			ds.setDriverID(rs.getInt("DRIVER_ID"));
			ds.setDriverLatitude(rs.getDouble("DRIVER_LATITUDE"));
			ds.setDriverLongitude(rs.getDouble("DRIVER_LONGITUDE"));
			ds.setStatus(DriversStatusus.valueOf(rs.getString("STATUS")));
			return ds;
		});
	}
	
	@Override
	public List<DriverStatusDisplay> getAllDriverDetailsWithStatusForDisplay() {
		return template.query(GET_ALL_DRIVER_DETAILS_WITH_STATUS_FOR_DISPLAY, (rs, rowNum) -> {
			Driver d = new Driver();
			DriverStatus ds = new DriverStatus();
			DriverStatusDisplay dsd = new DriverStatusDisplay(d, ds);
			d.setDriverID(rs.getInt("DRIVER_ID"));
			d.setDriverName(rs.getString("DRIVER_NAME"));
			d.setPhoneNo(rs.getString("PHONE_NO"));
			d.setVehicleID(rs.getInt("VEHICLE_ID"));
			ds.setDriverID(rs.getInt("DRIVER_ID"));
			ds.setDriverLatitude(rs.getDouble("DRIVER_LATITUDE"));
			ds.setDriverLongitude(rs.getDouble("DRIVER_LONGITUDE"));
			ds.setStatus(DriversStatusus.valueOf(rs.getString("STATUS")));
			return dsd;
		});
	}

	@Override
	public void markExistingBookingsInactive(int driverID) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("driverID", driverID);
		template.update(MARK_OLD_BOOKINGS_INACTIVE, params);
	}

	@Override
	public BookingDisplay getBookingInfo(int driverID) {
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("driverID", driverID);

		try {
			return template.queryForObject(GET_COMPLETE_BOOKING_INFO, params, new RowMapper<BookingDisplay>() {
				public BookingDisplay mapRow(ResultSet rs, int rowNum) throws SQLException {
					BookingDisplay bookingDisplay = new BookingDisplay();
					bookingDisplay.setBookingID(rs.getInt("booking_id"));
					bookingDisplay.setCustomerName(rs.getString("customer_name"));
					bookingDisplay.setCustomerLatitude(rs.getString("customer_latitude"));
					bookingDisplay.setCustomerLongitude(rs.getString("customer_longitude"));
					bookingDisplay.setDriverName(rs.getString("driver_name"));
					bookingDisplay.setDriverPhoneNo(rs.getString("driver_phone_no"));
					bookingDisplay.setDriverLatitude(rs.getString("driver_latitude"));
					bookingDisplay.setDriverLongitude(rs.getString("driver_longitude"));
					bookingDisplay.setVehicleType(rs.getString("vehicle_type"));
					bookingDisplay.setVehicleCapacity(rs.getInt("vehicle_capacity"));
					bookingDisplay.setManufacturer(rs.getString("manufacturer"));
					bookingDisplay.setModel(rs.getString("model"));

					return bookingDisplay;
				}
			});
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
}
