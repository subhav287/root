package com.loginext.challenge.entity;

import java.util.Date;

public class Driver implements Cloneable {
	private int driverID;
	private String driverName;
	private String phoneNo;
	private int vehicleID;
	private String driverPhotoUrl;
	private Date regDate;
	
	public int getDriverID() {
		return driverID;
	}
	
	public void setDriverID(int driverID) {
		this.driverID = driverID;
	}
	
	public String getDriverName() {
		return driverName;
	}
	
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	
	public String getPhoneNo() {
		return phoneNo;
	}
	
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public int getVehicleID() {
		return vehicleID;
	}
	
	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}
	
	public String getDriverPhotoUrl() {
		return driverPhotoUrl;
	}
	
	public void setDriverPhotoUrl(String driverPhotoUrl) {
		this.driverPhotoUrl = driverPhotoUrl;
	}
	
	public Date getRegDate() {
		return regDate;
	}
	
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
}
