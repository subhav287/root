package com.loginext.challenge.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Booking {
	private int bookingID;
	private int driverID;
	private String customerName;
	private double customerLatitude;
	private double customerLongitude;
	private boolean isActive;
	
	public Booking() {}
	
	public Booking(int driverID, String customerName, double customerLatitude, double customerLongitude) {
		this.driverID = driverID;
		this.customerName = customerName;
		this.customerLatitude = customerLatitude;
		this.customerLongitude = customerLongitude;
	}
	
	public int getBookingID() {
		return bookingID;
	}
	
	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public int getDriverID() {
		return driverID;
	}
	
	public void setDriverID(int driverID) {
		this.driverID = driverID;
	}
	
	public double getCustomerLatitude() {
		return customerLatitude;
	}
	
	public void setCustomerLatitude(double customerLatitude) {
		this.customerLatitude = customerLatitude;
	}
	
	public double getCustomerLongitude() {
		return customerLongitude;
	}
	
	public void setCustomerLongitude(double customerLongitude) {
		this.customerLongitude = customerLongitude;
	}
	
	public boolean isActive() {
		return isActive;
	}
	
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
}
