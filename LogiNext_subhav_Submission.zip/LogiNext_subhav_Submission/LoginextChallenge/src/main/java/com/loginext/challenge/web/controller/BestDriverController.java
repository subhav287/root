package com.loginext.challenge.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.loginext.challenge.model.BookingDisplay;
import com.loginext.challenge.web.service.BookingService;

@Controller
public class BestDriverController {
	
	@Autowired
	private BookingService service;
	
	@RequestMapping(value="/best-driver", method = RequestMethod.POST)
    public String getBestDriver(ModelMap model, @RequestParam String name, @RequestParam String latitude, @RequestParam String longitude){
		model.put("customerName", name);
        model.put("customerLatitude", Double.parseDouble(latitude));
        model.put("customerLongitude", Double.parseDouble(longitude));
        
		int bestDriver = service.assignBestDriver(model);
        
		if (bestDriver == -1)
			return "driver-unavailable";
		else {
			model.put("bestDriver", bestDriver);
            BookingDisplay bookingDisplay = service.makeBooking(model);
            model.put("bookingDisplay", bookingDisplay);
            return "booking-confirmation";
        }
    }
	
	@ExceptionHandler(java.lang.Exception.class)
	public ModelAndView handleException(HttpServletRequest request, Exception e) {
		ModelAndView model = new ModelAndView();
		model.addObject("url", request.getRequestURL());
		model.addObject("exception", e);
		model.setViewName("error");
		return model;
	}
}
