package com.loginext.challenge.dao;

import java.util.List;

import com.loginext.challenge.entity.Booking;
import com.loginext.challenge.entity.DriverStatus;
import com.loginext.challenge.model.BookingDisplay;
import com.loginext.challenge.model.DriverStatusDisplay;

public interface ILoginextDAO {
	public void updateDriversCoordinates(List<DriverStatus> driverStatusList);
	public int updateDriverStatus(int driverID, String status);
	public void createBooking(Booking booking);
	public List<DriverStatusDisplay> getAllDriverDetailsWithStatusForDisplay();
	public void markExistingBookingsInactive(int driverID);
	public BookingDisplay getBookingInfo(int driverID);
	public List<DriverStatus> getAllAvailableDrivers();
	public DriverStatusDisplay getDriverAndStatusDetailsByDriverID(int driverID);
	public int updateDriverStatusAndCoordinates(int driverID, String status, double latitude, double longitude);
}
