package com.loginext.challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.loginext.challenge")
@EntityScan("com.loginext.challenge")
public class LoginextChallengeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginextChallengeApplication.class, args);
	}

}
