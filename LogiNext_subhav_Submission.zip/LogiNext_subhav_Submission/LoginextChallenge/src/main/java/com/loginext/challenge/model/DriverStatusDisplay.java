package com.loginext.challenge.model;

import com.loginext.challenge.entity.Driver;
import com.loginext.challenge.entity.DriverStatus;

public class DriverStatusDisplay {
	private Driver driver;
	private DriverStatus driverStatus;
	
	public DriverStatusDisplay() {}
	
	public DriverStatusDisplay(Driver driver, DriverStatus driverStatus) {
		this.driver = driver;
		this.driverStatus = driverStatus;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}

	public DriverStatus getDriverStatus() {
		return driverStatus;
	}

	public void setDriverStatus(DriverStatus driverStatus) {
		this.driverStatus = driverStatus;
	}
}
