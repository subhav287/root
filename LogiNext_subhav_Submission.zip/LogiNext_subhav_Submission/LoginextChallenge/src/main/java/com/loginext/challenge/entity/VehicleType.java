package com.loginext.challenge.entity;

public enum VehicleType {
	SMALL("Small"),
	MEDIUM("Medium"),
	LARGE("Large"),
	LUXURY("Luxury");
	
	private String type;
	
	VehicleType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return this.type;
	}
}
