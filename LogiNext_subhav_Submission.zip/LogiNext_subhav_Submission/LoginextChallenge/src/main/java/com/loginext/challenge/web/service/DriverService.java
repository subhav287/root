package com.loginext.challenge.web.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loginext.challenge.dao.LoginextJDBCMySqlDAO;
import com.loginext.challenge.model.DriverStatusDisplay;

@Service
public class DriverService {
	@Autowired
	private LoginextJDBCMySqlDAO dao;
	
	public List<DriverStatusDisplay> getAllDriverDetailsWithStatusForDisplay() {
		List<DriverStatusDisplay> drivers = dao.getAllDriverDetailsWithStatusForDisplay();
		return drivers.stream()
			.sorted((DriverStatusDisplay o1, DriverStatusDisplay o2)->o1.getDriver().getDriverID() - o2.getDriver().getDriverID())
			.collect(Collectors.toList());
	}

	public DriverStatusDisplay getDriverStatusDetailsByID(int driverID) {
		return dao.getDriverAndStatusDetailsByDriverID(driverID);
	}
	
	public int updateDriverStatusAndCoordinates(int driverID, String status, double latitude, double longitude) {
		return dao.updateDriverStatusAndCoordinates(driverID, status, latitude, longitude);
	}
}
