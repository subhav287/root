package com.loginext.challenge.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.loginext.challenge.model.DriverStatusDisplay;
import com.loginext.challenge.web.service.DriverService;

@Controller
public class DriverController {
	@Autowired
	private DriverService service;

	@RequestMapping(value = "/list-driver-status", method = RequestMethod.GET)
	public String showDrivers(ModelMap model) {
		List<DriverStatusDisplay> drivers = service.getAllDriverDetailsWithStatusForDisplay();

		model.put("drivers", drivers);
		return "list-driver-status";
	}

	@RequestMapping(value = "/driver-id-page", method = RequestMethod.GET)
	public String showDriverIDPage(ModelMap model) {
		return "driver-id-page";
	}

	@RequestMapping(value = "/driver-update-details", method = RequestMethod.POST)
	public String showDriverUpdateDetails(ModelMap model, @RequestParam String driverID) {
		DriverStatusDisplay driverStatusDetails = service.getDriverStatusDetailsByID(Integer.parseInt(driverID));

		if (driverStatusDetails != null) {
			model.put("driverStatusDetails", driverStatusDetails);
			return "driver-update-details";
		} else {
			model.put("errorMessage", "Details Not Found for Driver ID: !"+ driverID);
			return "error";
		}
	}
	
	@RequestMapping(value = "/update-driver-details-action", method = RequestMethod.POST)
	public String updateDriverStatusAndCoordinates(ModelMap model, @RequestParam String driverID, @RequestParam String driverLatitude, @RequestParam String driverLongitude, @RequestParam String driverStatus) {
		int count = service.updateDriverStatusAndCoordinates(Integer.parseInt(driverID), driverStatus, Double.parseDouble(driverLatitude), Double.parseDouble(driverLongitude));

		if (count > 0) {
			return "success-driver-update";
		} else {
			model.put("errorMessage", "Could not update details for Driver ID: !"+ driverID);
			return "error";
		}
	}
}
