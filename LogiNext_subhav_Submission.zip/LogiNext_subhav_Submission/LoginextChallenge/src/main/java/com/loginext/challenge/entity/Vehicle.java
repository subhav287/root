package com.loginext.challenge.entity;

import java.util.Date;

public class Vehicle {
	private int vehicheID;
	private VehicleType vehicleType;
	private int vehicleCapacity;
	private String manufacturer;
	private String model;
	private String govtRegId;
	private Date purchaseDate;
	
	public int getVehicheID() {
		return vehicheID;
	}
	
	public void setVehicheID(int vehicheID) {
		this.vehicheID = vehicheID;
	}
	
	public VehicleType getVehicleType() {
		return vehicleType;
	}
	
	public void setVehicleType(VehicleType vehicleType) {
		this.vehicleType = vehicleType;
	}
	
	public int getVehicleCapacity() {
		return vehicleCapacity;
	}
	
	public void setVehicleCapacity(int vehicleCapacity) {
		this.vehicleCapacity = vehicleCapacity;
	}
	
	public String getManufacturer() {
		return manufacturer;
	}
	
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public String getGovtRegId() {
		return govtRegId;
	}
	
	public void setGovtRegId(String govtRegId) {
		this.govtRegId = govtRegId;
	}
	
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
}
