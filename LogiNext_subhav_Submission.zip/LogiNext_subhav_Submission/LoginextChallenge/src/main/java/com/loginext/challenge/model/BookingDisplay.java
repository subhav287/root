package com.loginext.challenge.model;

public class BookingDisplay {
	private int bookingID;
	private String customerName;
	private String customerLatitude;
	private String customerLongitude;
	private String driverName;
	private String driverPhoneNo;
	private String driverLatitude;
	private String driverLongitude;
	private String vehicleType;
	private int vehicleCapacity;
	private String manufacturer;
	private String model;
	
	public int getBookingID() {
		return bookingID;
	}
	
	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getCustomerLatitude() {
		return customerLatitude;
	}
	
	public void setCustomerLatitude(String customerLatitude) {
		this.customerLatitude = customerLatitude;
	}
	
	public String getCustomerLongitude() {
		return customerLongitude;
	}
	
	public void setCustomerLongitude(String customerLongitude) {
		this.customerLongitude = customerLongitude;
	}
	
	public String getDriverName() {
		return driverName;
	}
	
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	
	public String getDriverPhoneNo() {
		return driverPhoneNo;
	}
	
	public void setDriverPhoneNo(String driverPhoneNo) {
		this.driverPhoneNo = driverPhoneNo;
	}
	
	public String getDriverLatitude() {
		return driverLatitude;
	}
	
	public void setDriverLatitude(String driverLatitude) {
		this.driverLatitude = driverLatitude;
	}
	
	public String getDriverLongitude() {
		return driverLongitude;
	}
	
	public void setDriverLongitude(String driverLongitude) {
		this.driverLongitude = driverLongitude;
	}
	
	public String getVehicleType() {
		return vehicleType;
	}
	
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	
	public int getVehicleCapacity() {
		return vehicleCapacity;
	}
	
	public void setVehicleCapacity(int vehicleCapacity) {
		this.vehicleCapacity = vehicleCapacity;
	}
	
	public String getManufacturer() {
		return manufacturer;
	}
	
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
}
