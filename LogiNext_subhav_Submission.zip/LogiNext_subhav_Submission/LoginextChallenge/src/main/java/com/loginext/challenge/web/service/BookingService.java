package com.loginext.challenge.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.loginext.challenge.dao.LoginextJDBCMySqlDAO;
import com.loginext.challenge.entity.Booking;
import com.loginext.challenge.entity.DriverStatus;
import com.loginext.challenge.entity.DriversStatusus;
import com.loginext.challenge.model.BookingDisplay;

@Service
public class BookingService {
	private static final double RADIUS_OF_EARTH_KM = 6371;
	
	@Autowired
	private LoginextJDBCMySqlDAO dao;
	
	@Transactional
	public BookingDisplay makeBooking(ModelMap model) {
		int driverID = (int)model.get("bestDriver");
		double customerLatitude = (Double)model.get("customerLatitude");
		double customerLongitude = (Double)model.get("customerLongitude");
		Booking booking = new Booking(driverID, (String) model.get("customerName"), customerLatitude, customerLongitude);
		dao.updateDriverStatus(driverID, DriversStatusus.AVAILABLE.getText());
		dao.markExistingBookingsInactive(driverID);
		dao.createBooking(booking);
		return dao.getBookingInfo(driverID);
	}
	
	public int assignBestDriver(ModelMap model) {
		int bestDriverID = -1;
		double minDistance = Double.MAX_VALUE;
		double customerLatitude = (Double)model.get("customerLatitude");
		double customerLongitude = (Double)model.get("customerLongitude");
		List<DriverStatus> driversStatus = dao.getAllAvailableDrivers();
		
		for(DriverStatus ds : driversStatus) {
			double distance = distance(ds.getDriverLatitude(), customerLatitude, ds.getDriverLongitude(), customerLongitude);
			if(distance < minDistance) {
				minDistance = distance;
				bestDriverID = ds.getDriverID();
			}
		}
		
		return bestDriverID;
	}
	
	
	public static double distance(double latitude1, double latitude2, double longitude1, double longitude2) {
		longitude1 = Math.toRadians(longitude1);
		longitude2 = Math.toRadians(longitude2);
		latitude1 = Math.toRadians(latitude1);
		latitude2 = Math.toRadians(latitude2);
		
		/** Haversine formula */
		double diffLongitude = longitude2 - longitude1;
		double diffLatitude = latitude2 - latitude1;
		double a = Math.pow(Math.sin(diffLatitude / 2), 2) + Math.cos(latitude1) * Math.cos(latitude2) * Math.pow(Math.sin(diffLongitude / 2), 2);
		double c = 2 * Math.asin(Math.sqrt(a));
		
		return (c * RADIUS_OF_EARTH_KM);
	}
}
