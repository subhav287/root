package com.loginext.challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginextChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
