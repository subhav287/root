CREATE TABLE loginext.VEHICLE
(
vehicle_id int unsigned auto_increment primary key,
vehicle_type varchar(10) default 'Small',
vehicle_capacity integer default 4, 
manufacturer varchar(30) not null,
model varchar(20) not null,
govt_reg_id varchar(30) not null,
purchase_date timestamp default current_timestamp
);

insert into loginext.VEHICLE (vehicle_type, vehicle_capacity, manufacturer, model, govt_reg_id) values ('Small', 4, 'Maruti-Suzuki', 'Wagnor', 'MH012018MATCH75');
insert into loginext.VEHICLE (vehicle_type, vehicle_capacity, manufacturer, model, govt_reg_id) values ('Medium', 4, 'Hyundai', 'Xcent', 'MH032011CELSO21');
insert into loginext.VEHICLE (vehicle_type, vehicle_capacity, manufacturer, model, govt_reg_id) values ('Luxury', 4, 'Audi', 'A4', 'TOTCHEENDED172');
insert into loginext.VEHICLE (vehicle_type, vehicle_capacity, manufacturer, model, govt_reg_id) values ('Large', 6, 'Toyota', 'A4', 'RATSTOH286223');
insert into loginext.VEHICLE (vehicle_type, vehicle_capacity, manufacturer, model, govt_reg_id) values ('Small', 4, 'Hyundai', 'I10', 'TARIRALAKS534');
--__________________________________________________________________________________________________________________________________________________________________________________

CREATE TABLE loginext.DRIVER 
(
driver_id int unsigned auto_increment primary key,
driver_name varchar(30) not null,
phone_no varchar(15) not null,
vehicle_id int unsigned unique,
driver_photo_url varchar(2000),
reg_date timestamp default current_timestamp,
constraint fk_driver_vehicle foreign key(vehicle_id) references VEHICLE(vehicle_id),
constraint check_driver_phone_no CHECK (phone_no NOT LIKE '%[^0-9+-.]%')
);


insert into loginext.DRIVER (driver_name, phone_no, vehicle_id) values ('Rajesh', '9867480153', 1);
insert into loginext.DRIVER (driver_name, phone_no, vehicle_id) values ('Jack', '9004321234', 4);
insert into loginext.DRIVER (driver_name, phone_no, vehicle_id) values ('Alladin', '8254321978', 2);
insert into loginext.DRIVER (driver_name, phone_no, vehicle_id) values ('Harpreet', '7890512784', 5);
insert into loginext.DRIVER (driver_name, phone_no, vehicle_id) values ('Bhargav', '9854054906', 3);

--__________________________________________________________________________________________________________________________________________________________________________________

CREATE TABLE loginext.DRIVER_STATUS
(
driver_id int unsigned not null,
driver_latitude DECIMAL(10,8),
driver_longitude DECIMAL(11,8),
status varchar(10),
constraint fk_driverstatus_driver foreign key(driver_id) references DRIVER(driver_id)
);


insert into loginext.DRIVER_STATUS (driver_id, driver_latitude, driver_longitude, status) values (1, '12.45834', '6.589345', "AVAILABLE");
insert into loginext.DRIVER_STATUS (driver_id, driver_latitude, driver_longitude, status) values (2, '2.348953', '23.234234', "AVAILABLE");
insert into loginext.DRIVER_STATUS (driver_id, driver_latitude, driver_longitude, status) values (3, '78.345', '150.3403', "AVAILABLE");
insert into loginext.DRIVER_STATUS (driver_id, driver_latitude, driver_longitude, status) values (4, '54.127854', '116.43', "AVAILABLE");
insert into loginext.DRIVER_STATUS (driver_id, driver_latitude, driver_longitude, status) values (5, '47.75654', '88.546423', "AVAILABLE");

--__________________________________________________________________________________________________________________________________________________________________________________

CREATE TABLE loginext.BOOKING
(
booking_id bigint unsigned auto_increment primary key,
customer_name varchar(30) not null,
driver_id int unsigned not null,
customer_latitude DECIMAL(10,8),
customer_longitude DECIMAL(11,8),
is_active BOOLEAN,
constraint fk_booking_driver foreign key(driver_id) references DRIVER(driver_id)
);

--__________________________________________________________________________________________________________________________________________________________________________________